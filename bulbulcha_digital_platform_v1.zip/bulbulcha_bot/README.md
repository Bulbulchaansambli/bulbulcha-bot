# BULBULCHA qabul boti

Shermat Yormatov nomidagi “BULBULCHA” bolalar xor va raqs ansambli uchun Telegram qabul boti.

## Funksiyalar
- Onlayn ariza qabul qilish
- Tug‘ilgan sana bo‘yicha yoshni avtomatik hisoblash
- 4–7, 7–10, 10–14 yosh guruhlarini avtomatik aniqlash
- Xor va raqs jadvali
- Foto/video qabul qilish
- Admin ID ga yangi ariza yuborish
- Galereya
- `/stats` statistikasi
- `/export` CSV/Excel uchun arizalarni olish

## Render sozlamalari
Environment variables:

- `BOT_TOKEN` — BotFather bergan yangi token
- `ADMIN_ID` — sizning Telegram ID raqamingiz

Botdagi `/myid` buyrug‘i orqali Telegram ID ni bilib olasiz.

## Ishga tushirish
```bash
pip install -r requirements.txt
BOT_TOKEN="TOKEN" ADMIN_ID="123456789" python bot.py
```
