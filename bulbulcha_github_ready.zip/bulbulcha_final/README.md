# BULBULCHA qabul boti

Shermat Yormatov nomidagi **“BULBULCHA” bolalar xor va raqs ansambli** uchun Telegram qabul boti.

## Funksiyalar

- Onlayn ariza qabul qilish
- Tug‘ilgan sana bo‘yicha yoshni avtomatik hisoblash
- 4–7, 7–10, 10–14 yosh guruhlarini avtomatik aniqlash
- Xor va raqs jadvali
- Foto va video qabul qilish
- Arizani administratorga yuborish
- `/stats` statistikasi
- `/export` CSV fayl olish
- `/applications` oxirgi arizalarni ko‘rish
- `/broadcast matn` ommaviy xabar yuborish

## Render sozlamalari

Render’da **Worker** sifatida ishga tushiriladi.

Environment variables:

```text
BOT_TOKEN=BotFather bergan yangi token
ADMIN_IDS=Sizning Telegram ID raqamingiz
```

Agar bir nechta admin bo‘lsa:

```text
ADMIN_IDS=111111111,222222222
```

## Muhim xavfsizlik

Tokenni GitHub’ga yozmang. Faqat Render → Environment bo‘limiga kiriting.

## BotFather tavsiya matnlari

### Description
Shermat Yormatov nomidagi “BULBULCHA” bolalar xor va raqs ansamblining rasmiy qabul boti.

### About
BULBULCHA qabul boti: ansambl haqida ma’lumot, yosh guruhlari, jadval, manzil va onlayn ariza.

### Commands
```text
start - Botni boshlash
stats - Statistika
export - Arizalarni CSV formatda olish
applications - Oxirgi arizalar
cancel - Jarayonni bekor qilish
```
