import csv
import os
import re
import sqlite3
from datetime import date, datetime
from pathlib import Path
from typing import Optional, Tuple

from dotenv import load_dotenv
from telegram import (
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    Update,
)
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_IDS = [int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()]
DB_PATH = Path(os.getenv("DB_PATH", "bulbulcha.db"))
EXPORT_DIR = Path("exports")
EXPORT_DIR.mkdir(exist_ok=True)

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN topilmadi. Render Environment yoki .env ichiga kiriting.")

# Conversation states
(
    CHILD_NAME,
    BIRTH_DATE,
    GENDER,
    DIRECTION,
    EXPERIENCE,
    EXPERIENCE_DETAIL,
    PARENT_NAME,
    PHONE,
    DISTRICT,
    PHOTO,
    VIDEO,
    POEM,
    CONFIRM,
) = range(13)

MAIN_MENU = ReplyKeyboardMarkup(
    [
        ["🎼 Ansambl haqida", "👶 Yosh guruhlari"],
        ["🎤 Xor", "💃 Raqs"],
        ["📅 Mashg‘ulot jadvali", "🖼 Galereya"],
        ["📝 Qabulga yozilish"],
        ["📍 Manzil", "☎️ Bog‘lanish"],
        ["📢 Telegram kanal", "📸 Instagram"],
        ["❓ Savol-javob"],
    ],
    resize_keyboard=True,
)

GENDER_KB = ReplyKeyboardMarkup([["👦 O‘g‘il", "👧 Qiz"], ["❌ Bekor qilish"]], resize_keyboard=True)
DIRECTION_KB = ReplyKeyboardMarkup([["🎤 Xor", "💃 Raqs"], ["🎭 Xor va raqs"], ["❌ Bekor qilish"]], resize_keyboard=True)
YES_NO_KB = ReplyKeyboardMarkup([["✅ Ha", "❌ Yo‘q"], ["❌ Bekor qilish"]], resize_keyboard=True)
SKIP_KB = ReplyKeyboardMarkup([["⏭ O‘tkazib yuborish"], ["❌ Bekor qilish"]], resize_keyboard=True)
PHONE_KB = ReplyKeyboardMarkup([[KeyboardButton("📱 Telefon raqamni yuborish", request_contact=True)], ["❌ Bekor qilish"]], resize_keyboard=True)
CONFIRM_KB = ReplyKeyboardMarkup([["✅ Tasdiqlash", "✏️ Qayta boshlash"], ["❌ Bekor qilish"]], resize_keyboard=True)

ABOUT_TEXT = """🎼 <b>Shermat Yormatov nomidagi “BULBULCHA”</b>

<b>Bolalar xor va raqs ansambli</b> — O‘zbekistonning taniqli bolalar ijodiy jamoalaridan biri.

Ansamblda bolalarning musiqiy eshitishi, ovozi, sahna madaniyati, jamoada ishlash ko‘nikmasi, raqs harakati va ijodiy salohiyati rivojlantiriladi.

Qabul yil davomida olib boriladi. Mashg‘ulotlar bepul.
"""

GROUPS_TEXT = """👶 <b>Yosh guruhlari</b>

🟢 <b>4–7 yosh</b> — kichik/tayyorlov guruh
🔵 <b>7–10 yosh</b> — o‘rta guruh
🟣 <b>10–14 yosh</b> — katta guruh

Bot tug‘ilgan sanaga qarab yoshni avtomatik hisoblab, mos guruhni aniqlaydi.
"""

CHOIR_TEXT = """🎤 <b>Xor yo‘nalishi</b>

Sinovda bolaning:
• musiqiy eshitishi;
• ritmni his qilishi;
• ovozi va intonatsiyasi;
• yoshiga mos she’r aytishi;
• sahnadagi erkinligi kuzatiladi.

<b>Xor guruhlari:</b>
🟢 4–7 yosh — Kichik xor
🔵 7–10 yosh — O‘rta xor
🟣 10–14 yosh — Katta xor
"""

DANCE_TEXT = """💃 <b>Raqs yo‘nalishi</b>

Sinovda bolaning:
• ritmni his qilishi;
• harakat koordinatsiyasi;
• moslashuvchanligi;
• sahna madaniyati;
• ijodga qiziqishi kuzatiladi.

<b>Raqs guruhlari:</b>
🟢 4–7 yosh — Tayyorlov raqs
🔵 7–10 yosh — O‘rta raqs
🟣 10–14 yosh — Katta raqs
"""

SCHEDULE_TEXT = """📅 <b>Mashg‘ulot jadvali</b>

🎤 <b>Xor guruhlari</b>

🟢 <b>Kichik xor</b> — 4–7 yosh
Chorshanba: 14:00–17:00
Shanba/Yakshanba: 11:00–14:00
<i>Vaqtlarda o‘zgarish bo‘lishi mumkin, oldindan xabar beriladi.</i>

🔵 <b>O‘rta xor</b> — 7–10 yosh
Chorshanba/Shanba: 17:00–19:30
Yakshanba: 10:00–13:00

🟣 <b>Katta xor</b> — 10–14 yosh
Jadval administrator tomonidan aniqlashtiriladi.

💃 <b>Raqs guruhlari</b>

🟢 <b>Tayyorlov raqs</b> — 4–7 yosh
Seshanba/Payshanba/Shanba: 16:30–18:00

🔵 <b>O‘rta raqs</b> — 7–10 yosh
Seshanba/Payshanba/Shanba: 14:00–16:00

🟣 <b>Katta raqs</b> — 10–14 yosh
Seshanba/Payshanba/Shanba: 18:00–20:00
"""

CONTACT_TEXT = """☎️ <b>Bog‘lanish</b>

📞 +998 98 123 15 25
📢 Telegram: https://t.me/bulbulcha_uz
📸 Instagram: https://www.instagram.com/bulbulcha_official
"""

ADDRESS_TEXT = """📍 <b>Manzil</b>

Toshkent shahri, Yunusobod tumani,
Amir Temur tor ko‘chasi, 119A uy.

🗺 Xarita:
https://maps.app.goo.gl/3dNnULeHAbknYGak6
"""

FAQ_TEXT = """❓ <b>Ko‘p beriladigan savollar</b>

<b>Qabul qachon?</b>
Yil davomida.

<b>Mashg‘ulotlar pullikmi?</b>
Yo‘q, bepul.

<b>Necha yoshdan qabul qilinadi?</b>
4 yoshdan 14 yoshgacha.

<b>Tinglov kuni qachon?</b>
Ariza qabul qilingach, administrator ota-onani chaqiradi.

<b>Bola nima tayyorlab kelishi kerak?</b>
Yoshiga mos she’r.

<b>Xor va raqsni birga tanlash mumkinmi?</b>
Ha, mumkin.
"""

GALLERY_TEXT = """🖼 <b>Galereya</b>

Foto va videolarni rasmiy sahifalarimizda kuzatib boring:

📢 Telegram: https://t.me/bulbulcha_uz
📸 Instagram: https://www.instagram.com/bulbulcha_official
"""


def db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db() -> None:
    with db() as con:
        con.execute(
            """
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                telegram_id INTEGER,
                username TEXT,
                child_name TEXT,
                birth_date TEXT,
                age_text TEXT,
                age_years INTEGER,
                group_name TEXT,
                gender TEXT,
                direction TEXT,
                experience TEXT,
                experience_detail TEXT,
                parent_name TEXT,
                phone TEXT,
                district TEXT,
                photo_file_id TEXT,
                video_file_id TEXT,
                poem TEXT,
                status TEXT DEFAULT 'new'
            )
            """
        )


def parse_birth_date(text: str) -> Optional[date]:
    text = text.strip().replace("/", ".").replace("-", ".")
    m = re.fullmatch(r"(\d{1,2})\.(\d{1,2})\.(\d{4})", text)
    if not m:
        return None
    day, month, year = map(int, m.groups())
    try:
        return date(year, month, day)
    except ValueError:
        return None


def age_from_birth(born: date) -> Tuple[int, int, str]:
    today = date.today()
    years = today.year - born.year - ((today.month, today.day) < (born.month, born.day))
    months = (today.year - born.year) * 12 + today.month - born.month - (1 if today.day < born.day else 0)
    months_after_years = max(0, months - years * 12)
    return years, months_after_years, f"{years} yosh {months_after_years} oy"


def group_for_age(age: int, direction: str) -> str:
    if age < 4:
        return "Yosh kichik: 4 yoshdan boshlab qabul qilinadi"
    if age > 14:
        return "Yosh katta: 14 yoshgacha qabul qilinadi"
    if 4 <= age < 7:
        return "4–7 yosh — Kichik/Tayyorlov guruh"
    if 7 <= age < 10:
        return "7–10 yosh — O‘rta guruh"
    return "10–14 yosh — Katta guruh"


def normalize_phone(text: str) -> str:
    cleaned = re.sub(r"[^0-9+]", "", text)
    return cleaned or text.strip()


def application_summary(data: dict) -> str:
    return f"""🟢 <b>YANGI ARIZA</b>

👦 <b>Bola:</b> {data.get('child_name','')}
📅 <b>Tug‘ilgan sana:</b> {data.get('birth_date','')}
🎂 <b>Yoshi:</b> {data.get('age_text','')}
📚 <b>Guruh:</b> {data.get('group_name','')}
👤 <b>Jinsi:</b> {data.get('gender','')}
🎯 <b>Yo‘nalish:</b> {data.get('direction','')}
🎼 <b>Tajribasi:</b> {data.get('experience','')}
📝 <b>Tajriba izohi:</b> {data.get('experience_detail','') or '—'}
👨‍👩‍👧 <b>Ota-ona:</b> {data.get('parent_name','')}
☎️ <b>Telefon:</b> {data.get('phone','')}
🏠 <b>Tuman:</b> {data.get('district','')}
📖 <b>She’r:</b> {data.get('poem','') or '—'}

Telegram ID: <code>{data.get('telegram_id','')}</code>
Username: @{data.get('username') or 'yo‘q'}
"""


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    await update.message.reply_html(
        f"""🎼 <b>Shermat Yormatov nomidagi “BULBULCHA”</b>
<b>Bolalar xor va raqs ansambli</b> rasmiy qabul botiga xush kelibsiz!

Assalomu alaykum, {user.first_name or 'aziz ota-ona'}!

Bu bot orqali ansambl haqida ma’lumot olishingiz va farzandingizni onlayn ro‘yxatdan o‘tkazishingiz mumkin.
""",
        reply_markup=MAIN_MENU,
    )


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.clear()
    await update.message.reply_text("Jarayon bekor qilindi.", reply_markup=MAIN_MENU)
    return ConversationHandler.END


async def menu_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = update.message.text or ""
    mapping = {
        "🎼 Ansambl haqida": ABOUT_TEXT,
        "👶 Yosh guruhlari": GROUPS_TEXT,
        "🎤 Xor": CHOIR_TEXT,
        "💃 Raqs": DANCE_TEXT,
        "📅 Mashg‘ulot jadvali": SCHEDULE_TEXT,
        "🖼 Galereya": GALLERY_TEXT,
        "📍 Manzil": ADDRESS_TEXT,
        "☎️ Bog‘lanish": CONTACT_TEXT,
        "❓ Savol-javob": FAQ_TEXT,
        "📢 Telegram kanal": "📢 Rasmiy Telegram kanal:\nhttps://t.me/bulbulcha_uz",
        "📸 Instagram": "📸 Rasmiy Instagram sahifa:\nhttps://www.instagram.com/bulbulcha_official",
    }
    if text in mapping:
        await update.message.reply_html(mapping[text], reply_markup=MAIN_MENU, disable_web_page_preview=False)
        return
    await smart_answer(update, context)


async def smart_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = (update.message.text or "").lower()
    if any(w in text for w in ["narx", "pul", "to'lov", "tolov", "pullik", "bepul"]):
        await update.message.reply_text("Mashg‘ulotlar bepul. Qabul yil davomida olib boriladi.", reply_markup=MAIN_MENU)
    elif any(w in text for w in ["manzil", "qayer", "lokatsiya", "xarita"]):
        await update.message.reply_html(ADDRESS_TEXT, reply_markup=MAIN_MENU)
    elif any(w in text for w in ["yosh", "necha", "4", "5", "6", "7", "10", "14"]):
        await update.message.reply_html(GROUPS_TEXT, reply_markup=MAIN_MENU)
    elif any(w in text for w in ["telefon", "aloqa", "nomer", "raqam"]):
        await update.message.reply_html(CONTACT_TEXT, reply_markup=MAIN_MENU)
    elif any(w in text for w in ["jadval", "vaqt", "soat", "mashg"]):
        await update.message.reply_html(SCHEDULE_TEXT, reply_markup=MAIN_MENU)
    else:
        await update.message.reply_text("Savolingiz bo‘yicha menyudan bo‘lim tanlang yoki “📝 Qabulga yozilish” tugmasini bosing.", reply_markup=MAIN_MENU)


async def register_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.clear()
    await update.message.reply_text("📝 Qabulga yozilish boshlandi.\n\nFarzandingizning F.I.Sh.ni yozing:", reply_markup=ReplyKeyboardMarkup([["❌ Bekor qilish"]], resize_keyboard=True))
    return CHILD_NAME


async def get_child_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data["child_name"] = update.message.text.strip()
    await update.message.reply_text("📅 Tug‘ilgan sanasini kiriting.\n\nMasalan: 15.08.2020")
    return BIRTH_DATE


async def get_birth_date(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    born = parse_birth_date(update.message.text)
    if not born:
        await update.message.reply_text("Sana noto‘g‘ri. Iltimos, mana shunday kiriting: 15.08.2020")
        return BIRTH_DATE
    years, months, age_text = age_from_birth(born)
    group = group_for_age(years, "")
    context.user_data.update({"birth_date": born.strftime("%d.%m.%Y"), "age_years": years, "age_text": age_text, "group_name": group})
    if years < 4 or years > 14:
        await update.message.reply_text(f"Farzandingiz yoshi: {age_text}.\n{group}\n\nQo‘shimcha ma’lumot uchun: +998 98 123 15 25", reply_markup=MAIN_MENU)
        return ConversationHandler.END
    await update.message.reply_text(f"✅ Yoshi: {age_text}\n📚 Guruh: {group}\n\nJinsini tanlang:", reply_markup=GENDER_KB)
    return GENDER


async def get_gender(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data["gender"] = update.message.text.strip()
    await update.message.reply_text("Yo‘nalishni tanlang:", reply_markup=DIRECTION_KB)
    return DIRECTION


async def get_direction(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data["direction"] = update.message.text.strip()
    await update.message.reply_text("Farzandingiz avval musiqa yoki raqs bilan shug‘ullanganmi?", reply_markup=YES_NO_KB)
    return EXPERIENCE


async def get_experience(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    ans = update.message.text.strip()
    context.user_data["experience"] = ans
    if "Ha" in ans:
        await update.message.reply_text("Qayerda va qancha muddat shug‘ullanganini qisqacha yozing:", reply_markup=ReplyKeyboardMarkup([["⏭ O‘tkazib yuborish"], ["❌ Bekor qilish"]], resize_keyboard=True))
        return EXPERIENCE_DETAIL
    context.user_data["experience_detail"] = ""
    await update.message.reply_text("Ota yoki onaning F.I.Sh.ni yozing:", reply_markup=ReplyKeyboardMarkup([["❌ Bekor qilish"]], resize_keyboard=True))
    return PARENT_NAME


async def get_experience_detail(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    text = update.message.text.strip()
    context.user_data["experience_detail"] = "" if "O‘tkazib" in text else text
    await update.message.reply_text("Ota yoki onaning F.I.Sh.ni yozing:")
    return PARENT_NAME


async def get_parent_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data["parent_name"] = update.message.text.strip()
    await update.message.reply_text("Telefon raqamingizni yuboring yoki yozing:", reply_markup=PHONE_KB)
    return PHONE


async def get_phone(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message.contact:
        phone = update.message.contact.phone_number
    else:
        phone = normalize_phone(update.message.text)
    context.user_data["phone"] = phone
    await update.message.reply_text("Yashash tumaningizni yozing.\nMasalan: Yunusobod", reply_markup=ReplyKeyboardMarkup([["❌ Bekor qilish"]], resize_keyboard=True))
    return DISTRICT


async def get_district(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data["district"] = update.message.text.strip()
    await update.message.reply_text("📷 Farzandingiz fotosuratini yuboring.\nYubormasangiz “O‘tkazib yuborish” tugmasini bosing.", reply_markup=SKIP_KB)
    return PHOTO


async def get_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message.photo:
        context.user_data["photo_file_id"] = update.message.photo[-1].file_id
    else:
        context.user_data["photo_file_id"] = ""
    await update.message.reply_text("🎥 30–60 soniyalik video yuboring.\nYubormasangiz “O‘tkazib yuborish” tugmasini bosing.", reply_markup=SKIP_KB)
    return VIDEO


async def get_video(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message.video:
        context.user_data["video_file_id"] = update.message.video.file_id
    else:
        context.user_data["video_file_id"] = ""
    await update.message.reply_text("📖 Bola tinglovga yoshiga mos she’r tayyorlab keladi.\nQaysi she’rni aytishini yozing yoki “O‘tkazib yuborish” tugmasini bosing.", reply_markup=SKIP_KB)
    return POEM


async def get_poem(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    text = update.message.text.strip()
    context.user_data["poem"] = "" if "O‘tkazib" in text else text
    data = context.user_data
    await update.message.reply_html("Arizani tekshiring:\n\n" + application_summary(data) + "\nTasdiqlaysizmi?", reply_markup=CONFIRM_KB)
    return CONFIRM


async def confirm_application(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    text = update.message.text.strip()
    if "Qayta" in text:
        return await register_start(update, context)
    if "Tasdiqlash" not in text:
        return await cancel(update, context)

    data = dict(context.user_data)
    user = update.effective_user
    data["telegram_id"] = user.id
    data["username"] = user.username or ""
    data["created_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with db() as con:
        cur = con.execute(
            """
            INSERT INTO applications
            (created_at, telegram_id, username, child_name, birth_date, age_text, age_years, group_name, gender, direction, experience, experience_detail, parent_name, phone, district, photo_file_id, video_file_id, poem)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                data.get("created_at"), data.get("telegram_id"), data.get("username"), data.get("child_name"),
                data.get("birth_date"), data.get("age_text"), data.get("age_years"), data.get("group_name"),
                data.get("gender"), data.get("direction"), data.get("experience"), data.get("experience_detail"),
                data.get("parent_name"), data.get("phone"), data.get("district"), data.get("photo_file_id"),
                data.get("video_file_id"), data.get("poem"),
            ),
        )
        app_id = cur.lastrowid

    data["id"] = app_id
    for admin_id in ADMIN_IDS:
        try:
            await context.bot.send_message(admin_id, f"Ariza №{app_id}\n" + application_summary(data), parse_mode=ParseMode.HTML)
            if data.get("photo_file_id"):
                await context.bot.send_photo(admin_id, data["photo_file_id"], caption=f"Ariza №{app_id} — foto")
            if data.get("video_file_id"):
                await context.bot.send_video(admin_id, data["video_file_id"], caption=f"Ariza №{app_id} — video")
        except Exception as exc:
            print(f"Admin {admin_id} ga yuborilmadi: {exc}")

    await update.message.reply_html(
        f"""✅ <b>Arizangiz muvaffaqiyatli qabul qilindi.</b>

Ariza raqami: <b>№{app_id}</b>

Administrator tez orada siz bilan bog‘lanib, tinglov vaqtini ma’lum qiladi.

📍 Manzil: Toshkent shahri, Yunusobod tumani, Amir Temur tor ko‘chasi, 119A uy.
☎️ +998 98 123 15 25
""",
        reply_markup=MAIN_MENU,
    )
    context.user_data.clear()
    return ConversationHandler.END


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update.effective_user.id):
        return
    with db() as con:
        total = con.execute("SELECT COUNT(*) FROM applications").fetchone()[0]
        rows = con.execute("SELECT direction, COUNT(*) c FROM applications GROUP BY direction").fetchall()
        ages = con.execute("SELECT group_name, COUNT(*) c FROM applications GROUP BY group_name").fetchall()
    msg = f"📊 <b>Statistika</b>\n\nJami arizalar: <b>{total}</b>\n\n<b>Yo‘nalishlar:</b>\n"
    msg += "\n".join([f"• {r['direction']}: {r['c']}" for r in rows]) or "—"
    msg += "\n\n<b>Guruhlar:</b>\n"
    msg += "\n".join([f"• {r['group_name']}: {r['c']}" for r in ages]) or "—"
    await update.message.reply_html(msg)


async def applications_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update.effective_user.id):
        return
    with db() as con:
        rows = con.execute("SELECT id, child_name, age_text, direction, parent_name, phone, created_at FROM applications ORDER BY id DESC LIMIT 10").fetchall()
    if not rows:
        await update.message.reply_text("Hali arizalar yo‘q.")
        return
    msg = "📥 <b>Oxirgi arizalar</b>\n\n"
    for r in rows:
        msg += f"№{r['id']} — {r['child_name']} | {r['age_text']} | {r['direction']}\n{r['parent_name']} — {r['phone']}\n{r['created_at']}\n\n"
    await update.message.reply_html(msg)


async def export_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update.effective_user.id):
        return
    out = EXPORT_DIR / f"bulbulcha_applications_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
    with db() as con, out.open("w", newline="", encoding="utf-8-sig") as f:
        rows = con.execute("SELECT * FROM applications ORDER BY id DESC").fetchall()
        if not rows:
            await update.message.reply_text("Export uchun arizalar yo‘q.")
            return
        writer = csv.writer(f)
        writer.writerow(rows[0].keys())
        for row in rows:
            writer.writerow([row[k] for k in row.keys()])
    await update.message.reply_document(out.open("rb"), filename=out.name, caption="CSV/Excel uchun arizalar")


async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update.effective_user.id):
        return
    msg = " ".join(context.args).strip()
    if not msg:
        await update.message.reply_text("Foydalanish: /broadcast E’lon matni")
        return
    with db() as con:
        users = [r[0] for r in con.execute("SELECT DISTINCT telegram_id FROM applications WHERE telegram_id IS NOT NULL").fetchall()]
    sent = 0
    for uid in users:
        try:
            await context.bot.send_message(uid, msg)
            sent += 1
        except Exception:
            pass
    await update.message.reply_text(f"Yuborildi: {sent} ta foydalanuvchi")


def build_app() -> Application:
    init_db()
    app = Application.builder().token(BOT_TOKEN).build()

    conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^📝 Qabulga yozilish$"), register_start), CommandHandler("register", register_start)],
        states={
            CHILD_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_child_name)],
            BIRTH_DATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_birth_date)],
            GENDER: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_gender)],
            DIRECTION: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_direction)],
            EXPERIENCE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_experience)],
            EXPERIENCE_DETAIL: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_experience_detail)],
            PARENT_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_parent_name)],
            PHONE: [MessageHandler((filters.CONTACT | filters.TEXT) & ~filters.COMMAND, get_phone)],
            DISTRICT: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_district)],
            PHOTO: [MessageHandler((filters.PHOTO | filters.TEXT) & ~filters.COMMAND, get_photo)],
            VIDEO: [MessageHandler((filters.VIDEO | filters.TEXT) & ~filters.COMMAND, get_video)],
            POEM: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_poem)],
            CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, confirm_application)],
        },
        fallbacks=[CommandHandler("cancel", cancel), MessageHandler(filters.Regex("^❌ Bekor qilish$"), cancel)],
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("cancel", cancel))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CommandHandler("applications", applications_cmd))
    app.add_handler(CommandHandler("export", export_cmd))
    app.add_handler(CommandHandler("broadcast", broadcast))
    app.add_handler(conv)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, menu_handler))
    return app


if __name__ == "__main__":
    print("BULBULCHA bot ishga tushmoqda...")
    build_app().run_polling(allowed_updates=Update.ALL_TYPES)
